import sys
import os
from PyQt5.QtGui import QFont
from PyQt5.QtWidgets import QMainWindow, QApplication, QPushButton, QLabel, \
    QComboBox, QMessageBox, QTextBrowser, QFileDialog
from tools import shenon_encrypt, decode_shenon

class App(QMainWindow):
    def __init__(self):
        super().__init__()
        self.title = 'Сжиматор 3000 v1.0.1'
        self.setWindowTitle(self.title)
        self.move(300, 300)
        self.setFixedSize(500,500)
        self.setStyleSheet("background-color:#2b2a33; color: #218fa6")

        label = QLabel("Режим:", self)
        label.move(5, 10)
        label.resize(300, 50)
        label.setFont(QFont("Roboto", 40))

        self.mode_box = QComboBox(self)
        self.mode_box.addItems(["Кодирование", "Декодирование"])
        self.mode_box.move(250, 15)
        self.mode_box.setFont(QFont("Roboto",20))
        self.mode_box.resize(240, 50)

        self.run_button = QPushButton("Начать", self)
        self.run_button.pressed.connect(self.start)
        self.run_button.move(250, 100)
        self.run_button.setFont(QFont("Roboto",20))
        self.run_button.resize(240, 50)

        self.get_file = QPushButton("Файл", self)
        self.get_file.pressed.connect(self.get_file_f)
        self.get_file.move(5, 100)
        self.get_file.setFont(QFont("Roboto",20))
        self.get_file.resize(240, 50)

        self.log_text = QTextBrowser(self)
        self.log_text.setText("Тут будут логи")
        self.log_text.move(5, 160)
        self.log_text.setFont(QFont("Roboto",10))
        self.log_text.resize(490, 330)
        self.log_text.setStyleSheet('color:#ffee6b')

        self.file_path = None
        self.show()

    def start(self):
        if not self.file_path or not os.path.exists(self.file_path):
            self.log_text.append("ВЫБЕРИ ФАЙЛ!")
            msg = QMessageBox()
            msg.setIcon(QMessageBox.Critical)
            msg.setText("ВЫБЕРИ ФАЙЛ!")
            msg.setInformativeText('ВЫБЕРИ ФАЙЛ!')
            msg.setWindowTitle("ВЫБЕРИ ФАЙЛ!")
            msg.exec_()
            return

        mode = self.mode_box.currentText()
        self.log_text.append(f"\n{'=' * 40}\nЗапускаю...")
        self.log_text.append(f"Выбранный режим: {mode}")
        self.log_text.append(f"Файл: {self.file_path}")
        self.log_text.append(f"Размер  входного файла: {os.stat(self.file_path).st_size} байт")
        file_name = self.file_path.split('\\')[-1].split('/')[-1]
        self.log_text.append(f"Имя выходного файла: out/{file_name}.hola")
        if mode == 'Кодирование':
            encrypt_data = shenon_encrypt(self.file_path)
            self.log_text.append(f"Получена сжатая информация, записываю в файл...")
            open(f'out/{file_name}.hola', 'wb').write(encrypt_data)
            self.log_text.append(f"Информация записана в файл.\nРазмер до/после сжатия в байтах ниже")
            self.log_text.append(f"{' ' * 20}{os.stat(self.file_path).st_size}/{os.stat('out/' + file_name + '.hola').st_size}")

        else:
            try:
                decrypt_data = decode_shenon(self.file_path)
                self.log_text.append(f"Получена \"разжатая\" информация, записываю в файл...")
                open(f'out/decrypt_{file_name}.txt', 'w', encoding='utf-8').write(decrypt_data)
                self.log_text.append(f"Информация записана в файл.\nРазмер до/после разархивации в байтах ниже")
                self.log_text.append(f"{' ' * 20}{os.stat(self.file_path).st_size}/{os.stat('out/decrypt_' + file_name + '.txt').st_size}")
            except:
                self.log_text.append(f"Получена некоректный файл...")
    def get_file_f(self):
        tmp = QFileDialog.getOpenFileName()
        if tmp[0]:
            self.file_path = tmp[0]
            self.log_text.append(f"Выбран файл: {tmp[0]}")

if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = App()
    sys.exit(app.exec_())
