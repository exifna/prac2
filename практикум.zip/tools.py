import json
from typing import Set, List, Dict
from math import modf, fabs, floor, ceil, log2



# def get_binary_repr(f):
#     frac, fint = modf(fabs(f))  # split on fractional, integer parts
#     n, d = frac.as_integer_ratio()  # frac = numerator / denominator
#     return f'{floor(fint):b}.{n:0{d.bit_length() - 1}b}'

def get_binary_repr(base):
    res = '0.'
    for _ in range(15):
        base *= 2
        res += str(int(base // 1))
        base %= 1

    return res

def shenon_encrypt(fileName : str):
    Dict = dict()
    file_data = open(fileName, 'r', encoding='utf-8').read()
    for i in list(file_data):
        try:
            Dict[i] += 1
        except:
            Dict[i] = 1
    Sorted = list(reversed(sorted(Dict, key=Dict.get)))
    second_step = dict()
    for i in Sorted:
        second_step[i] = Dict[i] / len(file_data)
    second_step_b = dict()
    Sum = 0
    for i in list(second_step):
        second_step_b[i] = Sum
        Sum += second_step[i]
    return_data = dict()
    for i in second_step_b:
        return_data[i] = str(get_binary_repr(second_step_b[i]))[2:ceil(abs(log2(second_step[i]))) + 2]

    max_len = len(return_data[max(return_data, key =return_data.get)])
    tmp = ''.join([return_data[x] for x in file_data])
    End = len(tmp)
    if len(tmp) % 8 != 0:
        tmp = tmp +  '0' * (8-(len(tmp) % 8))
    Tmp = list()

    for n in range(0, len(tmp), 8):
        Tmp.append(int(tmp[n:n+8], 2))

    datas = bytes(Tmp)
    slovar = json.dumps(return_data).replace(": \"", ':"').replace(', "', ',"')

    return (slovar + chr(1)).encode('utf-8') + (str(End) + chr(1)).encode('utf-8') + datas #+ chr(1).encode('utf-8') #+ str(len(da))

def get_key(d, value):
    for k, v in d.items():
        if v == value:
            return k

def decrypt_string_by_slovar(string : str, slovar : dict) -> str:
    key_list = list(slovar.keys())
    val_list = list(slovar.values())
    tmp_string = ''
    return_string = ''

    for i in string:
        tmp_string += i
        if tmp_string in val_list:
            return_string += key_list[val_list.index(tmp_string)]
            tmp_string = ''

    return return_string

    return_string = str()
    tmp = 0
    for i in info:
        return_string += key_list[val_list.index(string[tmp : tmp + i])]
        tmp += i
    return return_string


def decode_shenon(fileName : str):
    data = open(fileName, 'rb').read().split(chr(1).encode('utf-8'))
    slovar =  json.loads(data[0].decode('utf-8'))
    encrypt_data = chr(1).encode('utf-8').join(data[2:])
    End = int(data[1])
    encrypt_symbols = [bin(x)[2:] for x in encrypt_data]
    for i in range(len(encrypt_symbols)):
        encrypt_symbols[i] = encrypt_symbols[i].zfill(8)

    encrypt_symbols = ''.join(encrypt_symbols).ljust(End, '0')
    encrypt_symbols = encrypt_symbols[:End]

    return decrypt_string_by_slovar(encrypt_symbols, slovar)



# input_file = 'тест.txt'
# # input_file = 'test.txt'
# output_file = 'out.txt'
# encode_string = shenon_encrypt(input_file)
# open(output_file, 'wb').write(encode_string)
# print(decode_shenon(output_file))